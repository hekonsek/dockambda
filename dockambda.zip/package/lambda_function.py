import subprocess

def my_handler(event, context):
    result = subprocess.run(["./udocker", "run", "hello-world"], capture_output=True)
    print(result.stdout)
    print(result.stderr)
    message = result.stdout
    return {
        'message' : message
    }

